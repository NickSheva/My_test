from tkinter import *
import time
time.sleep(5)



window = Tk()
window.title('Calculate loan')
window.geometry('550x350')

label1 = Label(window, text= 'Input amount of loan: ', font='arial 14 bold')
label2 = Label(window, text= 'Interest rate: ', font='arial 14 bold')
label3 = Label(window, text= 'Number of days: ', font='arial 14 bold')
label4 = Label(window, text= 'Interest only: ', font='arial 14 bold')
label5 = Label(window, text= 'All amount and interest: ', font='arial 14 bold')

loan = Entry(window, font='arial 14 bold', borderwidth=3)
interest = Entry(window, font='arial 14 bold', borderwidth=3)
days = Entry(window, font='arial 14 bold', borderwidth=3)
interest_only = Entry(window, font='arial 14 bold', borderwidth=3)
all_amount = Entry(window, font='arial 14 bold', borderwidth=3)


label1.grid(row=0, column=0, padx=60, pady=10)
label2.grid(row=1, column=0, padx=60, pady=10)
label3.grid(row=2, column=0, padx=60, pady=10)
label4.grid(row=5, column=0, padx=60, pady=10)
label5.grid(row=6, column=0, padx=60, pady=10)

loan.grid(row=0, column=1)
interest.grid(row=1, column=1)
days.grid(row=2, column=1)
interest_only.grid(row=5, column=1, pady=1)
all_amount.grid(row=6, column=1, pady=1)

def clear():
    loan.delete(0, END)
    interest.delete(0, END)
    days.delete(0, END)
    interest_only.delete(0, END)
    all_amount.delete(0, END)

    loan.focus_set()

def calculate(loan, interest, days):
    loan = int(loan.get())
    interest = float(interest.get())
    days = int(days.get())

    interest_only.insert(0, round((loan * interest/100)*days))
    all_amount.insert(0, round(loan + (loan * interest / 100) * days))
    return

my_button = Button(window, text='CONVERT', font='arial 14 bold', padx=10, pady= 5, fg='green',
                   command=lambda: calculate(loan, interest, days))
clea = Button(window, text='CLEAR', font='arial 14 bold', padx=10, pady=5, fg='red', command=lambda: clear())

my_button.grid(row=4, column=1, columnspan=2)
clea.grid(row=7, column= 1, columnspan=1)



window.mainloop()